// Shared theme toggle logic (no localStorage per platform constraints — resets on reload)
function initTheme(){
  const root = document.documentElement;
  const btns = document.querySelectorAll('[data-theme-toggle]');
  btns.forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const isDark = root.getAttribute('data-theme') === 'dark';
      root.setAttribute('data-theme', isDark ? 'light' : 'dark');
      btns.forEach(b=> b.innerHTML = isDark ? MOON_ICON : SUN_ICON);
    });
  });
}
const SUN_ICON = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v2M12 19v2M5 5l1.5 1.5M17.5 17.5 19 19M3 12h2M19 12h2M5 19l1.5-1.5M17.5 6.5 19 5M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"/></svg>`;
const MOON_ICON = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>`;
document.addEventListener('DOMContentLoaded', initTheme);
