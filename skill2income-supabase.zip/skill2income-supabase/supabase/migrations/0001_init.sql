-- ============================================================
-- Skill2Income — Supabase schema
-- Run this in the Supabase SQL Editor, or via `supabase db push`
-- once this file sits in supabase/migrations/.
-- ============================================================

-- ---------- profiles (1:1 with auth.users) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Auto-create a profile row whenever someone signs up via Supabase Auth.
-- Reads the display name from the signUp() `options.data.name` metadata.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------- assessments ----------
create table if not exists public.assessments (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  answers jsonb not null,
  score int not null,
  breakdown jsonb not null,
  path text not null,
  created_at timestamptz not null default now()
);

alter table public.assessments enable row level security;

create policy "Users manage their own assessments"
  on public.assessments for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------- jobs (public catalogue, admin-managed) ----------
create table if not exists public.jobs (
  id bigint generated always as identity primary key,
  title text not null,
  company text not null,
  location text not null,
  salary_min int,
  salary_max int,
  tags jsonb not null default '[]'::jsonb
);

alter table public.jobs enable row level security;

create policy "Anyone signed in can read jobs"
  on public.jobs for select
  using (auth.role() = 'authenticated');

-- ---------- applications ----------
create table if not exists public.applications (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id bigint not null references public.jobs(id) on delete cascade,
  status text not null default 'applied',
  created_at timestamptz not null default now(),
  unique (user_id, job_id)
);

alter table public.applications enable row level security;

create policy "Users manage their own applications"
  on public.applications for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------- income_entries ----------
create table if not exists public.income_entries (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount numeric not null check (amount >= 0),
  note text,
  entry_date date not null default current_date,
  created_at timestamptz not null default now()
);

alter table public.income_entries enable row level security;

create policy "Users manage their own income entries"
  on public.income_entries for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------- tasks ----------
create table if not exists public.tasks (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null,
  done boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.tasks enable row level security;

create policy "Users manage their own tasks"
  on public.tasks for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------- chat_messages ----------
create table if not exists public.chat_messages (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','ai','system')),
  content text not null,
  mode text,
  lang text,
  created_at timestamptz not null default now()
);

alter table public.chat_messages enable row level security;

create policy "Users manage their own chat messages"
  on public.chat_messages for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ---------- seed jobs (idempotent) ----------
insert into public.jobs (title, company, location, salary_min, salary_max, tags)
select * from (values
  ('Junior Graphic Designer', 'Zenith Creatives', 'Remote · Nigeria', 100000, 140000, '["Graphic design","Remote"]'::jsonb),
  ('Social Media Manager', 'Kano Retail Hub', 'Kano, Nigeria', 70000, 90000, '["Sales","Writing"]'::jsonb),
  ('Data Entry Specialist', 'Flow Logistics', 'Remote · Nigeria', 45000, 60000, '["Writing"]'::jsonb),
  ('Customer Support Agent (Hausa/English)', 'PayFast NG', 'Remote · Nigeria', 80000, 80000, '["Sales"]'::jsonb),
  ('Tailoring Apprentice Lead', 'Amina Fashion House', 'Kano, Nigeria', 40000, 65000, '["Tailoring"]'::jsonb),
  ('Poultry Farm Assistant', 'GreenFields Agro', 'Kaduna, Nigeria', 35000, 55000, '["Farming"]'::jsonb),
  ('Freelance Content Writer', 'Remote Client Pool', 'Remote · Nigeria', 60000, 120000, '["Writing"]'::jsonb),
  ('Phone Repair Technician', 'TechFix Hub', 'Kano, Nigeria', 50000, 90000, '["Phone/laptop repair"]'::jsonb)
) as v(title, company, location, salary_min, salary_max, tags)
where not exists (select 1 from public.jobs);

-- ---------- default tasks whenever a new assessment is submitted ----------
create or replace function public.seed_tasks_for_assessment()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.tasks (user_id, label) values
    (new.user_id, 'Complete first lesson toward: ' || new.path),
    (new.user_id, 'Message AI mentor about your first step'),
    (new.user_id, 'Apply to 1 matched opportunity'),
    (new.user_id, 'Log this week''s income (even if ₦0)');
  return new;
end;
$$;

drop trigger if exists on_assessment_created on public.assessments;
create trigger on_assessment_created
  after insert on public.assessments
  for each row execute procedure public.seed_tasks_for_assessment();
