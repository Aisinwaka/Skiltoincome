// supabase/functions/ai-mentor/index.ts
//
// Deploy with: supabase functions deploy ai-mentor
// Set the secret with: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
//
// This function runs server-side inside Supabase, so the Anthropic key never
// reaches the browser. It verifies the caller's Supabase JWT, reads their
// latest assessment (for context), calls the real Anthropic API, and stores
// both sides of the conversation in chat_messages.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ANTHROPIC_API_KEY = Deno.env.get('ANTHROPIC_API_KEY');

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: CORS_HEADERS });

  try {
    const authHeader = req.headers.get('Authorization') ?? '';
    const jwt = authHeader.replace('Bearer ', '');
    if (!jwt) return json({ error: 'Missing Authorization header.' }, 401);

    // Client scoped to the caller's JWT — respects RLS for reads we do on their behalf.
    const userClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userErr } = await userClient.auth.getUser(jwt);
    if (userErr || !userData?.user) return json({ error: 'Invalid session.' }, 401);
    const userId = userData.user.id;

    const { message, mode, lang } = await req.json();
    if (!message) return json({ error: 'message is required.' }, 400);

    // Admin client (service role) for writes that must succeed regardless of RLS nuances,
    // always scoped explicitly to this userId below.
    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    await admin.from('chat_messages').insert({ user_id: userId, role: 'user', content: message, mode, lang });

    if (!ANTHROPIC_API_KEY) {
      const notice =
        "AI mentor isn't connected yet — no ANTHROPIC_API_KEY secret is set for this Supabase project. Run `supabase secrets set ANTHROPIC_API_KEY=sk-ant-...` to enable real AI responses.";
      await admin.from('chat_messages').insert({ user_id: userId, role: 'system', content: notice, mode, lang });
      return json({ reply: notice, connected: false });
    }

    const { data: profile } = await admin.from('profiles').select('name').eq('id', userId).single();
    const { data: assessment } = await admin
      .from('assessments')
      .select('score, path')
      .eq('user_id', userId)
      .order('id', { ascending: false })
      .limit(1)
      .maybeSingle();

    const systemPrompt = `You are the AI mentor inside Skill2Income, an economic mobility platform for Nigerians. The user is ${
      profile?.name || 'a user'
    }${
      assessment ? `, with an Income Readiness Score of ${assessment.score}/100 and a recommended path of "${assessment.path}"` : ''
    }. Respond in ${lang || 'English'}. Focus area: ${mode || 'career'} advice. Be practical, concrete, and encouraging, and reference Nigerian context (Naira amounts, local market realities) where relevant. Keep responses concise (under 120 words).`;

    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 400,
        system: systemPrompt,
        messages: [{ role: 'user', content: message }],
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      return json({ error: 'AI service error', detail: errText }, 502);
    }

    const data = await resp.json();
    const reply = (data.content ?? []).map((c: any) => c.text || '').join('\n') || '(empty response)';

    await admin.from('chat_messages').insert({ user_id: userId, role: 'ai', content: reply, mode, lang });

    return json({ reply, connected: true });
  } catch (e) {
    return json({ error: 'Unexpected server error.', detail: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
  });
}
